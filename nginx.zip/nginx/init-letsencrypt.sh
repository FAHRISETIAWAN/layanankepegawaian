#!/bin/bash

DOMAIN="itms.atrbpn.go.id"
EMAIL="admin@atrbpn.go.id"
CERT_PATH="/etc/letsencrypt/live/$DOMAIN"
DATA_PATH="./certbot"

# Jika cert sudah ada, skip
if [ -d "$DATA_PATH/conf/live/$DOMAIN" ]; then
  echo "### Sertifikat sudah ada untuk $DOMAIN, skip."
  exit 0
fi

echo "### Membuat dummy certificate untuk $DOMAIN ..."
mkdir -p "$DATA_PATH/conf/live/$DOMAIN"
docker compose run --rm --entrypoint "\
  openssl req -x509 -nodes -newkey rsa:2048 -days 1 \
    -keyout '/etc/letsencrypt/live/$DOMAIN/privkey.pem' \
    -out '/etc/letsencrypt/live/$DOMAIN/fullchain.pem' \
    -subj '/CN=localhost'" certbot

echo "### Start Nginx dengan dummy cert ..."
docker compose up --force-recreate -d nginx

echo "### Hapus dummy certificate ..."
docker compose run --rm --entrypoint "\
  rm -Rf /etc/letsencrypt/live/$DOMAIN && \
  rm -Rf /etc/letsencrypt/archive/$DOMAIN && \
  rm -Rf /etc/letsencrypt/renewal/$DOMAIN.conf" certbot

echo "### Request sertifikat Let's Encrypt untuk $DOMAIN ..."
docker compose run --rm --entrypoint "\
  certbot certonly --webroot \
    --webroot-path=/var/www/certbot \
    --email $EMAIL \
    --agree-tos \
    --no-eff-email \
    -d $DOMAIN" certbot

echo "### Reload Nginx ..."
docker compose exec nginx nginx -s reload

echo "### Selesai! HTTPS aktif untuk $DOMAIN"
